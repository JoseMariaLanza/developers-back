Footer
<?php /**PATH C:\xampp\htdocs\projects\sitenso\resources\views/footer.blade.php ENDPATH**/ ?>