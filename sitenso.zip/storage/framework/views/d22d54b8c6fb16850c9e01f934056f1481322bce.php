<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar</div>

                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($error); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('developers.update', $developer)); ?>" method="POST">
                            <div class="form-group">
                                <label for="name">Nombre</label>
                                <input type="text" name="name" class="form-control" required
                                    value="<?php echo e(old('name', $developer->name)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="profession">Profesión</label>
                                <input type="text" name="profession" class="form-control" required
                                    value="<?php echo e(old('profession', $developer->profession)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="position">Puesto</label>
                                <select name="position" class="form-control form-select"
                                    aria-label="Default select example">
                                    <option selected value="<?php echo e($developer->position); ?>"><?php echo e($developer->position); ?>

                                    </option>
                                    <?php if($developer->position == 'Frontend'): ?>
                                        <option value="Frontend" hidden>Frontend</option>
                                    <?php else: ?>
                                        <option value="Frontend">Frontend</option>
                                    <?php endif; ?>
                                    <?php if($developer->position == 'Backend'): ?>
                                        <option value="Backend" hidden>Backend</option>
                                    <?php else: ?>
                                        <option value="Backend">Backend</option>
                                    <?php endif; ?>
                                    <?php if($developer->position == 'Fullstack'): ?>
                                        <option value="FullStack" hidden>FullStack</option>
                                    <?php else: ?>
                                        <option value="FullStack">FullStack</option>
                                    <?php endif; ?>
                                </select>
                                
                            </div>
                            <div class="form-group">
                                <label for="technology">Tecnología</label>
                                <select name="technology" class="form-control form-select"
                                    aria-label="Default select example">
                                    <option selected value="<?php echo e($developer->technology); ?>"><?php echo e($developer->technology); ?>

                                    </option>
                                    <?php if($developer->technology == 'React'): ?>
                                        <option value="React" hidden>React</option>
                                    <?php else: ?>
                                        <option value="React">React</option>
                                    <?php endif; ?>
                                    <?php if($developer->technology == 'Laravel'): ?>
                                        <option value="Laravel" hidden>Laravel</option>
                                    <?php else: ?>
                                        <option value="Laravel">Laravel</option>
                                    <?php endif; ?>
                                    <?php if($developer->technology == 'Nodejs'): ?>
                                        <option value="Nodejs" hidden>Nodejs</option>
                                    <?php else: ?>
                                        <option value="Nodejs">Nodejs</option>
                                    <?php endif; ?>
                                </select>
                                
                            </div>
                            <div class="form-group">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="submit" value="Actualizar" class="btn btn-sm btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\sitenso\resources\views/developers/edit.blade.php ENDPATH**/ ?>