<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Editar</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('devs.update', $dev)); ?>" method="POST">
                        <div class="form-group">
                            <label for="name">Nombre</label>
                            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name', $dev->name)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="profession">Profesión</label>
                            <input type="text" name="profession" class="form-control" required value="<?php echo e(old('profession', $dev->profession)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="position">Puesto</label>
                            <input type="text" name="position" class="form-control" required value="<?php echo e(old('position', $dev->position)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="technology">Tecnología</label>
                            <input type="text" name="technology" class="form-control" required value="<?php echo e(old('technology', $dev->technology)); ?>">
                        </div>
                        <div class="form-group">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="submit" value="Actualizar" class="btn btn-sm btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\sitenso\resources\views/devs/edit.blade.php ENDPATH**/ ?>