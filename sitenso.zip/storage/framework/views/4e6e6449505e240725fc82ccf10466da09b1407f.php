<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 mx-auto">

                <div class="card border-0 shadow">
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($error); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('developers.store')); ?>" method="POST">
                            <div class="row">
                                <div class="col-sm-3">
                                    <input type="text" name="name" placeholder="Nombre" class="form-control"
                                        value="<?php echo e(old('name')); ?>">
                                </div>
                                <div class="col-sm-3">
                                    <input type="text" name="profession" placeholder="Profesión" class="form-control"
                                        value="<?php echo e(old('profession')); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-3">
                                    <input type="text" name="position" placeholder="Puesto" class="form-control"
                                        value="<?php echo e(old('position')); ?>">
                                </div>
                                <div class="col-sm-3">
                                    <input type="text" name="technology" placeholder="Tecnología" class="form-control"
                                        value="<?php echo e(old('technology')); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-auto">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <table class="table">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOMBRE</th>
                            <th>PROFESION</th>
                            <th>TECNOLOGÍA</th>
                            <th>PUESTO</th>
                            <th colspan="2">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($developer->id); ?></td>
                                <td><?php echo e($developer->name); ?></td>
                                <td><?php echo e($developer->profession); ?></td>
                                <td><?php echo e($developer->position); ?></td>
                                <td><?php echo e($developer->technology); ?></td>
                                <td>
                                    <a href="<?php echo e(route('developers.edit', $developer)); ?>"
                                        class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('developers.destroy', $developer)); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="submit" value="Eliminar" class="btn btn-sm btn-danger"
                                            onclick="return confirm('¿Desea eliminar... ?')" />
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\sitenso\resources\views/developers/index.blade.php ENDPATH**/ ?>