Menu
<?php /**PATH C:\xampp\htdocs\projects\sitenso\resources\views/header.blade.php ENDPATH**/ ?>